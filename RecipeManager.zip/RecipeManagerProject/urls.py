from django.contrib import admin
from django.urls import path, include
from recipes.views import homepage, signup

urlpatterns = [
    path('admin/', admin.site.urls),
    path('signup/', signup, name='signup'),
    path('', homepage, name='homepage'),
    path('accounts/', include('accounts.urls')),
    path('recipes/', include('recipes.urls')),
    path('ingredients/', include('ingredients.urls')),
    path('accounts/', include('django.contrib.auth.urls')),  # Include authentication URLs
]


