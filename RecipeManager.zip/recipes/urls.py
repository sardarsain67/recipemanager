# from django.urls import path
# from . import views

# urlpatterns = [
#     path('', views.recipe_list, name='recipe_list'),
#     path('create/', views.recipe_create, name='recipe_create'),
#     # path('recipes/<int:recipe_id>/', views.recipe_detail, name='recipe_detail'),
#     # path('<int:pk>/edit/', views.recipe_update, name='recipe_update'),

#     path('recipes/<int:recipe_id>/', views.recipe_detail, name='recipe_detail'),
#     path('recipes/<int:recipe_id>/edit/', views.recipe_update, name='recipe_update'),
    
#     path('<int:pk>/delete/', views.recipe_delete, name='recipe_delete'),
#     path('<int:pk>/check/', views.check_ingredients, name='check_ingredients'),
#     path('recipes/<int:recipe_id>/like/', views.like_recipe, name='like_recipe'),
# ]

# recipes/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.recipe_list, name='recipe_list'),
    path('create/', views.recipe_create, name='recipe_create'),
    path('recipes/<int:recipe_id>/', views.recipe_detail, name='recipe_detail'),
    path('recipes/<int:recipe_id>/edit/', views.recipe_update, name='recipe_update'),
    path('<int:pk>/delete/', views.recipe_delete, name='recipe_delete'),
    path('<int:pk>/check/', views.check_ingredients, name='check_ingredients'),
    path('<int:recipe_id>/like/', views.like_recipe, name='like_recipe'),
    path('ingredient-usage/', views.ingredient_usage_view, name='ingredient_usage'),
    path('trending-recipes/', views.trending_recipes_view, name='trending_recipes'),
]




