# from django.shortcuts import render, redirect, get_object_or_404
# from .models import Recipe
# from .forms import RecipeForm
# from django.contrib.auth.decorators import login_required
# from django.http import HttpResponse
# from django.contrib.auth.forms import UserCreationForm

# def signup(request):
#     if request.method == 'POST':
#         form = UserCreationForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('login')  # Redirect to login after successful signup
#     else:
#         form = UserCreationForm()
#     return render(request, 'signup.html', {'form': form})

# def homepage(request):
#     return render(request, 'homepage.html')

# def recipe_list(request):
#     recipes = Recipe.objects.all()
#     return render(request, 'recipes/recipe_list.html', {'recipes': recipes})

# def recipe_detail(request, recipe_id):
#     recipe = get_object_or_404(Recipe, pk=recipe_id)
#     return render(request, 'recipes/recipe_detail.html', {'recipe': recipe})

# @login_required
# def recipe_create(request):
#     if request.method == 'POST':
#         form = RecipeForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('recipe_list')
#     else:
#         form = RecipeForm()
#     return render(request, 'recipes/recipe_form.html', {'form': form})

# @login_required
# def recipe_update(request, pk):
#     recipe = get_object_or_404(Recipe, pk=pk)
#     if request.method == 'POST':
#         form = RecipeForm(request.POST, instance=recipe)
#         if form.is_valid():
#             form.save()
#             return redirect('recipe_detail', pk=recipe.pk)
#     else:
#         form = RecipeForm(instance=recipe)
#     return render(request, 'recipes/recipe_form.html', {'form': form})

# @login_required
# def recipe_delete(request, pk):
#     recipe = get_object_or_404(Recipe, pk=pk)
#     if request.method == 'POST':
#         recipe.delete()
#         return redirect('recipe_list')
#     return render(request, 'recipes/recipe_confirm_delete.html', {'recipe': recipe})

# @login_required
# def check_ingredients(request, pk):
#     recipe = get_object_or_404(Recipe, pk=pk)
#     user_ingredients = set(request.user.ingredients.all())  # Assuming a many-to-many relation
#     required_ingredients = set(recipe.ingredients.all())
#     missing_ingredients = required_ingredients - user_ingredients
#     return render(request, 'recipes/check_ingredients.html', {
#         'recipe': recipe,
#         'missing_ingredients': missing_ingredients,
#     })
from django.shortcuts import render, redirect, get_object_or_404
from .models import Recipe, Ingredient
from .forms import RecipeForm
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.http import HttpResponse
from django.http import JsonResponse
from django.db.models import Count
def signup(request):
    return HttpResponse("This is the signup page.")

def homepage(request):
    return render(request, 'homepage.html')

# def recipe_list(request):
#     recipes = Recipe.objects.all()
#     return render(request, 'recipes/recipe_list.html', {'recipes': recipes})

def recipe_list(request):
    search_query = request.GET.get('q', '')  # Get the search query from the URL parameters
    if search_query:
        recipes = Recipe.objects.filter(name__icontains=search_query)
    else:
        recipes = Recipe.objects.all()
    return render(request, 'recipes/recipe_list.html', {'recipes': recipes})
# def recipe_detail(request, recipe_id):
#     recipe = get_object_or_404(Recipe, pk=recipe_id)
#     return render(request, 'recipes/recipe_detail.html', {'recipe': recipe})
def recipe_detail(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)
    return render(request, 'recipes/recipe_detail.html', {'recipe': recipe})

@login_required
def like_recipe(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)
    if request.method == 'POST':
        if request.user in recipe.likes.all():
            recipe.likes.remove(request.user)
            liked = False
        else:
            recipe.likes.add(request.user)
            liked = True
        return JsonResponse({'liked': liked, 'total_likes': recipe.total_likes()})
    return JsonResponse({'error': 'Invalid request'}, status=400)

#########################

def ingredient_usage_view(request):
    ingredient_counts = Recipe.objects.values('ingredients__name').annotate(count=Count('ingredients')).order_by('-count')
    
    # Prepare the data to be JSON serializable
    ingredient_names = [item['ingredients__name'] for item in ingredient_counts]
    counts = [item['count'] for item in ingredient_counts]
    
    context = {
        'ingredient_counts_names': ingredient_names,
        'ingredient_counts_values': counts,
    }
    return render(request, 'recipes/ingredient_usage.html', context)

def trending_recipes_view(request):
    trending_recipes = Recipe.objects.annotate(like_count=Count('likes')).order_by('-like_count')[:5]
    
    # Prepare the data to be JSON serializable
    recipe_names = [recipe.name for recipe in trending_recipes]
    likes = [recipe.like_count for recipe in trending_recipes]
    
    context = {
        'trending_recipes_names': recipe_names,
        'trending_recipes_likes': likes,
    }
    return render(request, 'recipes/trending_recipes.html', context)
#####################

@login_required
def recipe_create(request):
    if request.method == 'POST':
        form = RecipeForm(request.POST)
        if form.is_valid():
            recipe = form.save(commit=False)
            recipe.user = request.user  # Set the user who created the recipe
            recipe.save()
            form.save_m2m()  # Save the many-to-many data for the form
            return redirect('recipe_list')
    else:
        form = RecipeForm()
    return render(request, 'recipes/recipe_form.html', {'form': form})

@login_required
def recipe_update(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)
    if recipe.user != request.user:
        return HttpResponseForbidden("You are not allowed to edit this recipe.")

    if request.method == "POST":
        # Assume you have a form class named RecipeForm
        form = RecipeForm(request.POST, instance=recipe)
        if form.is_valid():
            form.save()
            return redirect('recipe_detail', recipe_id=recipe.id)
    else:
        form = RecipeForm(instance=recipe)

    return render(request, 'recipes/recipe_form.html', {'form': form})


@login_required
def recipe_delete(request, pk):
    recipe = get_object_or_404(Recipe, pk=pk)
    if recipe.user != request.user:
        return HttpResponseForbidden("You are not allowed to delete this recipe.")

    if request.method == 'POST':
        recipe.delete()
        return redirect('recipe_list')
    return render(request, 'recipes/recipe_confirm_delete.html', {'recipe': recipe})

def check_ingredients(request, pk):
    recipe = get_object_or_404(Recipe, pk=pk)
    user_ingredients = set(request.user.ingredients.all())
    required_ingredients = set(recipe.ingredients.all())
    missing_ingredients = required_ingredients - user_ingredients
    return render(request, 'recipes/check_ingredients.html', {
        'recipe': recipe,
        'missing_ingredients': missing_ingredients,
    })

