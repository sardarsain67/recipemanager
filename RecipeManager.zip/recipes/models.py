# from django.db import models
# from ingredients.models import Ingredient
# from django.contrib.auth.models import User

# class Recipe(models.Model):
#     name = models.CharField(max_length=255)
#     description = models.TextField()
#     ingredients = models.ManyToManyField(Ingredient)
#     user = models.ForeignKey(User, on_delete=models.CASCADE)  # Link to User model

#     def __str__(self):
#         return self.name

##############################

# from django.db import models
# from ingredients.models import Ingredient
# from django.contrib.auth.models import User

# class Recipe(models.Model):
#     name = models.CharField(max_length=255)
#     description = models.TextField()
#     ingredients = models.ManyToManyField(Ingredient)
#     user = models.ForeignKey(User, on_delete=models.CASCADE)  # Link to User model
#     likes = models.ManyToManyField(User, related_name='liked_recipes', blank=True)

#     def __str__(self):
#         return self.name

#     def total_likes(self):
#         return self.likes.count()

##############################
from django.db import models
from ingredients.models import Ingredient
from django.contrib.auth.models import User

class Recipe(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    ingredients = models.ManyToManyField(Ingredient)
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Link to User model
    likes = models.ManyToManyField(User, related_name='liked_recipes', blank=True)

    def __str__(self):
        return self.name

    def total_likes(self):
        return self.likes.count()

