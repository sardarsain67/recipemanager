from django.shortcuts import render, redirect
from .models import Ingredient
from .forms import IngredientForm

def add_ingredient_view(request):
    if request.method == 'POST':
        form = IngredientForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('ingredient_list')  # Update to your desired redirect page
    else:
        form = IngredientForm()
    return render(request, 'ingredients/add_ingredient.html', {'form': form})

def ingredient_list(request):
    ingredients = Ingredient.objects.all()
    return render(request, 'ingredients/ingredient_list.html', {'ingredients': ingredients})
# def ingredient_list(request):
#     # Example: Fetch and display a list of ingredients
#     return render(request, 'ingredients/ingredient_list.html')




def ingredient_detail(request, pk):
    # Example: Fetch and display a single ingredient by primary key (pk)
    return render(request, 'ingredients/ingredient_detail.html')

