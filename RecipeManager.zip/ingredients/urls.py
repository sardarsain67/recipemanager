# from django.urls import path
# from . import views

# urlpatterns = [
#     path('', views.ingredient_list, name='ingredient_list'),
#     path('<int:pk>/', views.ingredient_detail, name='ingredient_detail'),
# ]
##############
from django.urls import path
from . import views
from .views import add_ingredient_view

urlpatterns = [
    path('', views.ingredient_list, name='ingredient_list'),
    path('<int:pk>/', views.ingredient_detail, name='ingredient_detail'),
    path('add/', add_ingredient_view, name='add_ingredient'),
]

